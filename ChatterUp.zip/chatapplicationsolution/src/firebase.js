import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyA_OgNKNgxcKZWGoTm7pH-u_sOf2Qb1Cso",
  authDomain: "chat-application-f4b01.firebaseapp.com",
  projectId: "chat-application-f4b01",
  storageBucket: "chat-application-f4b01.appspot.com",
  messagingSenderId: "487931849117",
  appId: "1:487931849117:web:bbf340e8c090a0ac542774"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore()
