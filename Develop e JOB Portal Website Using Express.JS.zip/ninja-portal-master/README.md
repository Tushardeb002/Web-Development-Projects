# Ninja Portal

## Purpose
To make my job easier 😴

## Stuff to Add
- Sound when freetime finishes.
