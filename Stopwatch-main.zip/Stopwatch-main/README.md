<p align="center">
    <img src="https://telegra.ph/file/3447671d88b84f167456f.gif">
</p>

# StopWatch By Rachit Pal

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-java.svg)](https://www.java.com/en/)
[![ForTheBadge built-with-love](http://ForTheBadge.com/images/badges/built-with-love.svg)](https://GitHub.com/Dank-del/) <br>
<a href="https://rachit-pal.github.io/Stopwatch/"> <img src="https://svgur.com/i/iob.svg" /> </a>

## Digital Stopwatch

A stopwatch is a timepiece designed to measure the amount of time that elapses between its activation and deactivation.
A large digital version of a stopwatch designed for viewing at a distance, as in a sports stadium, is called a stop clock

### This Digital Stopwatch Repository is made by [Rachit Pal](https://www.github.com/Rachit-Pal/)
